import { useState } from "react";
import Button from "./Button";
import Input from "./Input";
import { View, Text, StyleSheet, Switch } from "react-native";
import Materia from "./Materia";
import { listTitle } from "../labels";

export default function Main() {
  const [materias, setMaterias] = useState([]);
  const [text, setText] = useState("");
  // Estado do Switch "Mostrar apenas obrigatórias" — ainda sem lógica de
  // filtro real (desafio opcional), só guarda o valor selecionado por enquanto.
  const [apenasObrigatorias, setApenasObrigatorias] = useState(false);

  function adicionaMateria(nome) {
    const nomeLimpo = nome.trim();

    if (nomeLimpo.length === 0) {
      return;
    }

    const novaMateria = {
      id: Date.now(),
      nome: nomeLimpo,
    };

    setMaterias((prev) => [...prev, novaMateria]);
    setText("");
  }

  return (
    <View style={styles.container}>
      {/* alignItems: "center" alinha o input e o botão verticalmente no
          centro da linha, já que o botão é mais baixo que o input com
          padding. justifyContent não é setado aqui de propósito: o gap
          já cuida do espaçamento e o inputWrapper com flex: 1 é quem
          decide o quanto o botão "sobra" de espaço. */}
      <View style={styles.inputRow}>
        <View style={styles.inputWrapper}>
          <Input value={text} onChangeText={setText} />
        </View>
        <Button onPress={() => adicionaMateria(text)} />
      </View>

      {/* Switch "Mostrar apenas obrigatórias" — desafio opcional.
          justifyContent: "space-between" separa o texto e o switch nas
          pontas opostas da linha; alignItems: "center" mantém os dois
          alinhados no mesmo eixo vertical. */}
      <View style={styles.filtroRow}>
        <Text style={styles.filtroTexto}>Mostrar apenas obrigatórias</Text>
        <Switch
          value={apenasObrigatorias}
          onValueChange={setApenasObrigatorias}
        />
      </View>

      <Text style={styles.listaTitulo}>{listTitle}</Text>

      {materias.length === 0 ? (
        // justifyContent + alignItems centralizam a mensagem de "lista
        // vazia" tanto vertical quanto horizontalmente dentro do espaço
        // disponível, deixando o estado vazio visualmente equilibrado.
        <View style={styles.vazioContainer}>
          <Text style={styles.vazioTexto}>Não há nenhuma matéria</Text>
        </View>
      ) : (
        <View style={styles.lista}>
          {materias.map((materia) => (
            <Materia key={materia.id} nome={materia.nome} />
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: "#F5F5F7",
  },
  titulo: {
    fontSize: 26,
    fontWeight: "700",
    color: "#1C1C1E",
    marginBottom: 20,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 20,
  },
  inputWrapper: {
    flex: 1,
  },
  filtroRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  filtroTexto: {
    fontSize: 14,
    color: "#3C3C43",
  },
  listaTitulo: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1C1C1E",
    marginBottom: 12,
  },
  botaoAdicionar: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: "#34C759",
    alignItems: "center",
    justifyContent: "center",
  },
  textoBotaoAdicionar: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "600",
    lineHeight: 26,
  },
  lista: {
    // Sem gap aqui: o espaçamento entre os itens agora vem do
    // marginBottom de cada Materia, então não duplicamos o valor.
  },
  vazioContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 60,
  },
  vazioTexto: {
    fontSize: 16,
    color: "#8E8E93",
  },
});
