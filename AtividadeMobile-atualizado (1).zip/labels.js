export const title = "Meu Diário Acadêmico";
export const subtitle = "Organize as disciplinas do seu semestre";
export const placeholder = "adicione uma disciplina...";
export const buttonText = "Adicionar";
export const listTitle = "Disciplinas";
